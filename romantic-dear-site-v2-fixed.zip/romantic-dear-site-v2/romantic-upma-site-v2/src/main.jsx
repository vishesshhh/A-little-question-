import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const SECRET = "WANNA HAVE SOME GULU GULU";
const rows = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];

const heartSeeds = Array.from({length: 30}, (_, i) => ({
  left: `${(i * 31 + 5) % 103 - 2}%`,
  delay: `${(i * .63) % 10}s`,
  duration: `${10 + (i % 8)}s`,
  size: `${20 + (i * 11) % 48}px`,
  drift: `${-35 + (i * 17) % 70}px`
}));

function Background() {
  return <>
    <div className="ambient" />
    <div className="sparkles">{Array.from({length:28},(_,i)=>
      <i key={i} style={{
        left:`${(i*43+7)%98}%`,
        top:`${(i*29+3)%100}%`,
        width:`${3+(i%5)}px`,
        height:`${3+(i%5)}px`,
        animationDelay:`${(i*.37)%3.5}s`
      }} />
    )}</div>
    <div className="hearts-bg">
      {heartSeeds.map((h,i)=><span key={i} style={h}>❤️</span>)}
    </div>
  </>;
}

function Burst({n=12}) {
  return <div className="burst">{Array.from({length:n},(_,i)=>
    <span key={i} style={{"--a":`${i*360/n}deg`}}>❤️</span>
  )}</div>
}

function Intro({onDone}) {
  const [caught,setCaught]=useState(0);
  const [pops,setPops]=useState([]);
  const positions=[
    [17,38],[83,38],[17,65],[83,65],[50,86],
    [38,87],[63,87]
  ];

  const catchIt=(i)=>{
    if(i>=5) return;
    setPops(p=>[...p,{id:Date.now()}]);
    setCaught(c=> {
      const next=c+1;
      if(next===5) setTimeout(onDone,700);
      return next;
    });
  };

  return <section className="screen intro">
    {pops.map(p=><Burst key={p.id} />)}
    <div className="intro-top">
      <h1>Hey dear <span>❤️</span></h1>
      <p>I have a little question for you...</p>
      <p className="tiny">Catch the hearts first 👀</p>
      <div className="score">Hearts: {caught}/5 ❤️</div>
    </div>

    {positions.map(([x,y],i)=>
      <button
        key={i}
        className={`catch ${i<5 ? "" : "decoy"}`}
        style={{left:`${x}%`,top:`${y}%`,animationDelay:`${i*.18}s`}}
        onClick={()=>catchIt(i)}
      >❤️</button>
    )}

    {caught===5 && <div className="success-pop">You caught them all! 💕</div>}
  </section>
}

function Hidden({onDone}) {
  const [leaving,setLeaving]=useState(false);
  return <section className="screen hidden">
    <div className="hidden-card">
      <h2>Now there's something hidden...</h2>
      <p className="redline">Can you figure it out? 👀</p>
      <p className="hint">Use the keyboard to unlock it ❤️</p>
      <button className="go" onClick={()=>{
        setLeaving(true);
        setTimeout(onDone,520);
      }}>Let's go ❤️</button>
    </div>
    {leaving && <div className="transition-hearts"><Burst n={20}/></div>}
  </section>
}

function Secret({onDone}) {
  const [typed,setTyped]=useState("");
  const [shake,setShake]=useState(false);

  const press=(letter)=>{
    const expected=SECRET[typed.length];
    if(expected===" ") {
      if(letter===" ") setTyped(typed+" ");
      return;
    }
    if(letter===expected) {
      const next=typed+letter;
      setTyped(next);
      if(next===SECRET) setTimeout(onDone,900);
    } else {
      setShake(true);
      setTimeout(()=>setShake(false),300);
    }
  };

  useEffect(()=>{
    const handler=e=>{
      if(/^[a-zA-Z]$/.test(e.key)) press(e.key.toUpperCase());
      if(e.key===" ") press(" ");
    };
    addEventListener("keydown",handler);
    return ()=>removeEventListener("keydown",handler);
  },[typed]);

  const words=SECRET.split(" ");
  let cursor=0;

  return <section className="screen secret">
    <div className="secret-card">
      <h2>Type the secret message...</h2>
      <p className="hint faded">Tap the glowing letter ❤️</p>
      <div className={`secret-display ${shake?"shake":""}`}>
        {words.map((word,wi)=><React.Fragment key={wi}>
          {wi>0 && <span className="word-space"/>}
          <span className="word">
            {word.split("").map((_,j)=>{
              const index=cursor++;
              return <span key={j} className={index<typed.length?"filled":""}>
                {index<typed.length ? SECRET[index] : "_"}
              </span>
            })}
          </span>
        </React.Fragment>)}
      </div>

      <div className="keyboard">
        {rows.map((row,r)=><div className="keyrow" key={r}>
          {row.split("").map(letter=>{
            const expected=SECRET[typed.length];
            return <button
              key={letter}
              onClick={()=>press(letter)}
              className={`key ${expected===letter?"glow":""} ${typed.includes(letter)?"used":""}`}
            >{letter}</button>
          })}
        </div>)}
      </div>
      {typed.length===SECRET.length && <div className="unlock">Unlocked! ❤️</div>}
    </div>
  </section>
}

function Question({onYes}) {
  const [maybe,setMaybe]=useState(0);
  const [pos,setPos]=useState({x:0,y:0});
  const [moving,setMoving]=useState(false);
  const [burst,setBurst]=useState(false);
  const maybeRef=useRef(null);

  const moveMaybe=()=>{
    setMaybe(n=>n+1);
    setMoving(true);
    const maxX=Math.min(125, window.innerWidth*.25);
    const maxY=Math.min(180, window.innerHeight*.18);
    const x=(Math.random()*2-1)*maxX;
    const y=(Math.random()*2-1)*maxY;
    setPos({x,y});
  };

  const yes=()=>{
    setBurst(true);
    setTimeout(onYes,850);
  };

  return <section className="screen question">
    {burst && <Burst n={26}/>}
    <div className="question-card">
      <h2>Wanna have some gulu gulu? ❤️</h2>
      <p className="with">With me? 😳</p>

      <button className={`yes ${maybe>0?"yes-attention":""}`} onClick={yes}>
        YES 🙈❤️
      </button>

      {maybe>0 && <div className="try">
        <div>Hehe, nice try 😜</div>
        <strong>Just press YES ❤️</strong>
      </div>}

      <button
        ref={maybeRef}
        className={`maybe ${moving?"moved":""}`}
        style={{"--mx":`${pos.x}px`,"--my":`${pos.y}px`}}
        onClick={moveMaybe}
      >Maybe 👀</button>

      {maybe>1 && <div className="tease">Nope! 😝</div>}
    </div>
  </section>
}

function Final() {
  return <section className="screen final">
    <div className="final-card">
      <div className="big-heart">❤️</div>
      <h2>Wanna have some gulu gulu? ❤️</h2>
      <p className="with">With me? 😳</p>
      <h3>HEHE... I KNEW IT! ❤️</h3>
      <p className="looks">Looks like it's a YES. 🙈</p>
      <p className="sign">— dev</p>
      <div className="final-hearts">💕 💗 💕</div>
    </div>
  </section>
}

function App(){
  const [stage,setStage]=useState(0);
  return <main className="app">
    <Background/>
    {stage===0&&<Intro onDone={()=>setStage(1)}/>}
    {stage===1&&<Hidden onDone={()=>setStage(2)}/>}
    {stage===2&&<Secret onDone={()=>setStage(3)}/>}
    {stage===3&&<Question onYes={()=>setStage(4)}/>}
    {stage===4&&<Final/>}
  </main>
}

createRoot(document.getElementById("root")).render(<App/>);
